<?php
include_once("conexion.php"); // Asegúrate de que la ruta a tu archivo de conexión sea correcta

class UsuarioAdminModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }

    // Método para registrar un nuevo usuario
    public function registrarUsuario($nombre, $apaterno, $amaterno, $email, $password, $telefono = null, $id_puesto = null) {
        // Verificar si el email ya existe
        $stmt = $this->conexion->prepare("SELECT COUNT(*) FROM clientes WHERE email = :email");
        $stmt->execute([':email' => $email]);
    
        if ($stmt->fetchColumn() > 0) {
            return "El correo ya está registrado."; // Email ya registrado
        }
    
        // Preparar la consulta para insertar el nuevo usuario
        $stmt = $this->conexion->prepare("INSERT INTO clientes (nombre, apaterno, amaterno, email, Contraseña, telefono, Id_puestos) VALUES (:nombre, :apaterno, :amaterno, :email, :password, :telefono, :id_puesto)");
    
        // Encriptar la contraseña antes de guardarla
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
        // Ejecutar la consulta
        $resultado = $stmt->execute([
            ':nombre' => $nombre,
            ':apaterno' => $apaterno,
            ':amaterno' => $amaterno,
            ':email' => $email,
            ':password' => $passwordHash,
            ':telefono' => $telefono,
            ':id_puesto' => $id_puesto
        ]);
    
        return $resultado ? true : "Error al registrar el usuario."; // Retornar el resultado
    }

    // Método para obtener todos los usuarios
    public function obtenerTodosLosUsuarios() {
        $stmt = $this->conexion->prepare("SELECT * FROM clientes WHERE id_puestos != 1"); // Cambia 1 por el ID correspondiente a administradores
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Otros métodos para modificar, eliminar, etc. pueden ser añadidos aquí
    
}

?>