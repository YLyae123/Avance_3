<?php
include_once('conexion.php'); // Asegúrate de que la ruta a tu archivo de conexión sea correcta

class UsuarioModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }

    // Método para registrar un nuevo usuario
    public function registrarUsuario($nombre, $apaterno, $amaterno, $email, $password, $id_puesto, $telefono = null) {
        try {
            // Verificar si el email ya existe
            $stmt = $this->conexion->prepare("SELECT COUNT(*) FROM clientes WHERE email = :email");
            $stmt->execute([':email' => $email]);
            
            if ($stmt->fetchColumn() > 0) {
                return "El correo ya está registrado."; // Email ya registrado
            }
    
            // Preparar la consulta para insertar el nuevo usuario
            $stmt = $this->conexion->prepare("INSERT INTO clientes (nombre, apaterno, amaterno, email, Contraseña, telefono, Id_puestos) VALUES (:nombre, :apaterno, :amaterno, :email, :password, :telefono, :id_puesto)");
    
            // Encriptar la contraseña antes de guardarla
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
            // Ejecutar la consulta
            $resultado = $stmt->execute([
                ':nombre' => $nombre,
                ':apaterno' => $apaterno,
                ':amaterno' => $amaterno,
                ':email' => $email,
                ':password' => $passwordHash,
                ':telefono' => $telefono,
                ':id_puesto' => $id_puesto
            ]);
    
            return $resultado ? true : "Error al registrar el usuario."; // Retornar el resultado
        } catch (PDOException $e) {
            return "Error de base de datos: " . $e->getMessage(); // Manejo de error
        }
    }

    // Método para iniciar sesión
    public function ingresarUsuario($email, $password) {
        // Preparar la consulta para verificar el usuario
        $stmt = $this->conexion->prepare("SELECT * FROM clientes WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si el usuario fue encontrado
        if ($usuario && password_verify($password, $usuario['Contraseña'])) {
            return true; // Autenticación exitosa
        }

        return "Error al ingresar el usuario."; // Error en la autenticación
    }
    
    // Método para obtener datos del usuario por su correo electrónico
    public function getUserDataByEmail($email) {
        $stmt = $this->conexion->prepare("SELECT nombre, apaterno, id_puestos FROM clientes WHERE email = :email");
        $stmt->execute([':email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerTodosLosUsuarios() {
        // Modificar la consulta para obtener solo usuarios (excluyendo administradores)
        $stmt = $this->conexion->prepare("SELECT * FROM clientes WHERE id_puestos != 1"); // Cambia 1 por el ID correspondiente a administradores
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function modificarUsuario($id, $nombre, $apaterno, $amaterno, $email) {
        $stmt = $this->conexion->prepare("UPDATE clientes SET nombre = :nombre, apaterno = :apaterno, amaterno = :amaterno, email = :email WHERE id_usuario = :id");
        return $stmt->execute([':id' => $id, ':nombre' => $nombre, ':apaterno' => $apaterno, ':amaterno' => $amaterno, ':email' => $email]);
    }
    
    public function eliminarUsuario($id) {
        $stmt = $this->conexion->prepare("DELETE FROM clientes WHERE id_cliente = :id");
        return $stmt->execute([':id' => $id]);
    }
    
    public function obtenerUsuarioPorId($id) {
        $stmt = $this->conexion->prepare("SELECT * FROM clientes WHERE id_cliente = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>