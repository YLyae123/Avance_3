<?php
include_once("conexion.php"); // Asegúrate de incluir el archivo de conexión

class CatalogoModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }

    // Método para obtener todos los paquetes
    public function obtenerPaquetes() {
        // Preparar la consulta SQL
        $consulta = "SELECT id_paquete, nombre_paquete, descripcion, costo, cupo_maximo FROM paquetes";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute();

        // Obtener los resultados
        $paquetes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $paquetes;
    }

    // Método para crear un nuevo paquete
    public function crearPaquete($nombre_paquete, $descripcion, $costo, $cupo_maximo) {
        $consulta = "INSERT INTO paquetes (nombre_paquete, descripcion, costo, cupo_maximo) VALUES (:nombre_paquete, :descripcion, :costo, :cupo_maximo)";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute([
            ':nombre_paquete' => $nombre_paquete,
            ':descripcion' => $descripcion,
            ':costo' => $costo,
            ':cupo_maximo' => $cupo_maximo
        ]);
    }

    // Método para modificar un paquete existente
    public function modificarPaquete($id_paquete, $nombre_paquete, $descripcion, $costo, $cupo_maximo) {
        $consulta = "UPDATE paquetes SET nombre_paquete = :nombre_paquete, descripcion = :descripcion, costo = :costo, cupo_maximo = :cupo_maximo WHERE id_paquete = :id_paquete";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute([
            ':id_paquete' => $id_paquete,
            ':nombre_paquete' => $nombre_paquete,
            ':descripcion' => $descripcion,
            ':costo' => $costo,
            ':cupo_maximo' => $cupo_maximo
        ]);
    }

    // Método para eliminar un paquete
    public function eliminarPaquete($id_paquete) {
        $consulta = "DELETE FROM paquetes WHERE id_paquete = :id_paquete";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute([':id_paquete' => $id_paquete]);
    }

    // Método para obtener un paquete específico por ID
    public function obtenerPaquetePorId($id_paquete) {
        $consulta = "SELECT id_paquete, nombre_paquete, descripcion, costo, cupo_maximo FROM paquetes WHERE id_paquete = :id_paquete";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute([':id_paquete' => $id_paquete]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>