<?php
class IndexModel{
      
}
?>