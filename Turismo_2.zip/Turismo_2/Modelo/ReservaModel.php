<?php
include_once("conexion.php"); // Asegúrate de que la ruta a tu archivo de conexión sea correcta

class ReservaModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }

    // Método para guardar la reserva
    public function guardarReserva($ruta_id, $usuario_id) {
        $consulta = "INSERT INTO reservas (id_paquete, id_cliente, fecha_reserva, estado) VALUES (:ruta_id, :usuario_id, NOW(), 'pendiente')";
        $stmt = $this->conexion->prepare($consulta);
        
        try {
            return $stmt->execute([
                ':ruta_id' => $ruta_id,
                ':usuario_id' => $usuario_id
            ]);
        } catch (Exception $e) {
            error_log("Error al guardar reserva: " . $e->getMessage());
            return false; // Retorna false en caso de error
        }
    }

    // Método para obtener ruta por ID
    public function obtenerRutaPorId($id) {
        // Preparar la consulta SQL para obtener los detalles de la ruta
        $consulta = "SELECT * FROM rutas WHERE id = :id";
        $stmt = $this->conexion->prepare($consulta);
        
        try {
            // Ejecutar la consulta con el ID proporcionado
            $stmt->execute([':id' => $id]);
            
            // Devolver el resultado
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            // Manejo del error, puedes registrar el error o mostrar un mensaje
            error_log("Error al obtener ruta por ID: " . $e->getMessage()); // Registra el error en el log
            return null; // Retorna null en caso de error
        }
    }

    // Método para obtener reservas por ID de usuario
    public function obtenerReservasPorUsuario($usuario_id) {
        $consulta = "SELECT * FROM reservas WHERE id_cliente = :usuario_id";
        $stmt = $this->conexion->prepare($consulta);
        
        try {
            $stmt->execute([':usuario_id' => $usuario_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error al obtener reservas por usuario: " . $e->getMessage());
            return []; // Retorna un array vacío en caso de error
        }
    }
    public function obtenerReservas() {
        $consulta = "SELECT r.id_reserva, r.fecha_reserva, r.estado, c.nombre, c.apaterno, p.nombre_paquete 
                     FROM reservas r 
                     JOIN clientes c ON r.id_cliente = c.id_cliente 
                     JOIN paquetes p ON r.id_paquete = p.id_paquete"; 
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>