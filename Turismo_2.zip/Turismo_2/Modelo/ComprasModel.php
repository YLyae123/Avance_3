<?php
include_once("Modelo/conexion.php"); 

class ComprasModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }
public function agregarCompra($usuario_id, $ruta_id, $estado) {
    $fecha_compra = date('Y-m-d H:i:s'); // Obtener la fecha y hora actual
    $consulta = "INSERT INTO compras (id_cliente,id_ruta,estado,fecha_compra) VALUES (:usuario_id, :ruta_id, :estado, :fecha_compra)";
    $stmt = $this->conexion->prepare($consulta);
    
    return $stmt->execute([
        ':usuario_id' => $usuario_id,
        ':ruta_id' => $ruta_id,
        ':estado' => $estado,
        ':fecha_compra' => $fecha_compra
    ]);
}

    // Método para obtener una compra específica por ID
    public function obtenerCompraPorId($id_compra) {
        $consulta = "SELECT * FROM compras WHERE id_compra = :id_compra"; // Asegúrate de que el nombre de la tabla y las columnas sean correctos
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute([':id_compra' => $id_compra]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para eliminar una compra
    public function eliminarCompra($id_compra) {
        $consulta = "DELETE FROM compras WHERE id_compra = :id_compra"; // Asegúrate de que el nombre de la tabla y las columnas sean correctos
        $stmt = $this->conexion->prepare($consulta);
        return $stmt->execute([':id_compra' => $id_compra]);
    }

    public function actualizarEstado($compra_id, $nuevo_estado) {
        $sql = "UPDATE compras SET estado = :nuevo_estado WHERE id_compra = :compra_id"; // Asegúrate de que el nombre de la tabla y las columnas sean correctos
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([':nuevo_estado' => $nuevo_estado, ':compra_id' => $compra_id]);
    }
}
?>