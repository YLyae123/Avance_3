<?php
include_once 'conexion.php'; // Asegúrate de que la ruta a tu archivo de conexión sea correcta

class RutasModel {
    private $conexion;

    public function __construct() {
        $this->conexion = new Conexion(); // Crear una nueva conexión a la base de datos
    }

    public function obtenerRutas() {
        // Preparar la consulta SQL
        $consulta = "SELECT id, ciudad_origen, ciudad_destino, descripcion, costo, tiempo_estimado FROM rutas";
        $stmt = $this->conexion->prepare($consulta);
        
        try {
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error al obtener rutas: " . $e->getMessage());
            return []; // Retorna un array vacío en caso de error
        }
    }
    public function obtenerRutaPorId($id) {
        // Preparar la consulta SQL para obtener los detalles de la ruta
        $consulta = "SELECT * FROM rutas WHERE id = :id";
        $stmt = $this->conexion->prepare($consulta);
        
        // Ejecutar la consulta con el ID proporcionado
        $stmt->execute([':id' => $id]);
        
        // Devolver el resultado
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>