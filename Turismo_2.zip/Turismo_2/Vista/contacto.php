<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contacto</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        header, footer {
            background-color: #00796b;
            color: white;
            text-align: center;
            padding: 1rem 0;
        }
        main {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
        }
        h1 {
            color: #00796b;
            text-align: center;
        }
        .contact-info {
            margin-bottom: 2rem;
            background: white;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .contact-info h2 {
            margin-top: 0;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        ul li {
            margin-bottom: 0.5rem;
        }
        ul li i {
            color: #00796b;
            margin-right: 10px;
        }
        .contact-form {
            background: white;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .contact-form label {
            display: block;
            margin: 0.5rem 0 0.2rem;
        }
        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .contact-form button {
            background-color: #00796b;
            color: white;
            border: none;
            padding: 0.7rem 1.5rem;
            border-radius: 4px;
            cursor: pointer;
        }
        .contact-form button:hover {
            background-color: #005a4e;
        }
    </style>
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <main>
        <h1>Contacto</h1>

        <section class="contact-info">
            <h2>Información de contacto</h2>
            <ul>
                <li><i class="fas fa-envelope"></i> Correo: <a href="mailto:contacto@chiapasturismo.mx">contacto@chiapasturismo.mx</a></li>
                <li><i class="fas fa-phone"></i> Teléfono: <a href="tel:+529612765685">+52 961 276 5685</a></li>
                <li><i class="fas fa-map-marker-alt"></i> Dirección: Calle Principal #123, San Cristóbal de las Casas, Chiapas</li>
                <li><i class="fas fa-facebook"></i> Facebook: <a href="https://facebook.com/chiapasturismo" target="_blank">facebook.com/chiapasturismo</a></li>
                <li><i class="fas fa-instagram"></i> Instagram: <a href="https://www.instagram.com/turismo_aventura_chiapas/profilecard/?igsh=czdmajR3ZmN6NXJy " target="_blank">@chiapasturismo</a></li>
                <li><i class="fas fa-twitter"></i> Twitter: <a href="https://x.com/Chiapas_Turismo?t=b_uu3q4DtavvAS7g6Z-zlA&s=09" target="_blank">@chiapasturismo</a></li>
            </ul>
        </section>

        <section class="contact-form">
            <h2>Envíanos un mensaje</h2>
            <form action="enviar_mensaje.php" method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>
                
                <label for="correo">Correo electrónico:</label>
                <input type="email" id="correo" name="correo" required>
                
                <label for="mensaje">Mensaje:</label>
                <textarea id="mensaje" name="mensaje" rows="5" required></textarea>
                
                <button type="submit">Enviar mensaje</button>
            </form>
        </section>
    </main>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>
