<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Información sobre Chiapas</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        header, footer {
            background-color: #00796b;
            color: white;
            text-align: center;
            padding: 1rem 0;
        }
        main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        h1, h2 {
            color: #00796b;
        }
        section {
            margin-bottom: 2rem;
            padding: 1rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        ul {
            padding-left: 20px;
        }
        ul li {
            margin-bottom: 0.5rem;
        }
        a {
            color: #00796b;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .image-container {
            text-align: center;
            margin: 1rem 0;
        }
        .image-container img {
            max-width: 100%;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <main>
        <h1>Información sobre Chiapas</h1>
        <section id="introduccion">
            <p>Chiapas, ubicado en el sureste de México, es una joya de biodiversidad, historia y tradiciones. Sus paisajes únicos y riqueza cultural lo convierten en un destino imperdible para viajeros de todo el mundo.</p>
            <div class="image-container">
            <img src="Vista/IMG/Paisaje.jpg" alt="Paisajes de chiapas">
        </section>

        <section id="atracciones-turisticas">
            <h2>Principales atracciones turísticas</h2>
            <ul>
                <li><strong>Cañón del Sumidero:</strong> Un majestuoso cañón que puedes explorar en lancha, con vistas impresionantes.</li>
                <li><strong>San Cristóbal de las Casas:</strong> Un pintoresco pueblo mágico famoso por su arquitectura colonial y su cultura viva.</li>
                <li><strong>Palenque:</strong> Zona arqueológica maya con templos impresionantes rodeados por la selva.</li>
                <li><strong>Lagunas de Montebello:</strong> Un paraíso natural con lagos de colores únicos.</li>
                <li><strong>Agua Azul:</strong> Cascadas cristalinas que son un espectáculo natural imperdible.</li>
            </ul>
            <div class="image-container">
                <img src="Vista/IMG/Sumidero.jpg" alt="Cañón del Sumidero">
            </div>
        </section>

        <section id="gastronomia">
            <h2>Gastronomía de Chiapas</h2>
            <p>La gastronomía de Chiapas es una mezcla de sabores tradicionales. No te pierdas:</p>
            <ul>
                <li><strong>Tamales de chipilín:</strong> Deliciosos tamales con una planta típica de la región.</li>
                <li><strong>Cochito horneado:</strong> Carne de cerdo preparada con especias locales.</li>
                <li><strong>Pozol:</strong> Una refrescante bebida de cacao y maíz.</li>
            </ul>
            <div class="image-container">
                <img src="Vista/IMG/Gastronomia.jpg" alt="Platillos de Chiapas">
            </div>
        </section>

        <section id="consejos">
            <h2>Consejos para tu visita</h2>
            <p>Para disfrutar al máximo de tu viaje a Chiapas:</p>
            <ul>
                <li>Empaca ropa ligera y cómoda, pero lleva un suéter para las noches frescas.</li>
                <li>Respeta las tradiciones y cultura de las comunidades locales.</li>
                <li>No olvides tu cámara para capturar los paisajes únicos.</li>
            </ul>
        </section>
    </main>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>
