<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compras Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php include 'Layout/header.php'; ?>
<body>
<div class="container mt-5">
    <h1>Compras, Apartados y Reservaciones</h1>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Monto</th>
                <th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($compras as $compra): ?>
                <tr>
                    <td><?php echo htmlspecialchars($compra['id']); ?></td>
                    <td><?php echo htmlspecialchars($compra['usuario']); ?></td>
                    <td><?php echo htmlspecialchars($compra['monto']); ?></td>
                    <td><?php echo htmlspecialchars($compra['fecha']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php include 'Layout/footer.php'; ?>
</body>
</html>
