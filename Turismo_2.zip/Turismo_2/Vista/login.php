<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <div class="row">
        <div class="col"></div>
        <div class="col">
            <section>
                <div class="mb-5">
                    <h2 class="display-5 text-center">Iniciar Sesión</h2>
                </div>
                <!-- Formulario de inicio de sesión -->
                <form action="index.php?i=inicio" method="POST">
                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" name="usuario" id="floatingEmail" required>
                        <label for="floatingEmail">Email</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" name="password" id="floatingPassword" required>
                        <label for="floatingPassword">Contraseña</label>
                    </div>
                    <div class="text-center mb-4">
                        <button type="submit" class="btn btn-success">Iniciar Sesión</button>
                    </div>
                </form>

                <!-- Mensajes de Error -->
                <?php if (isset($error)): ?>
                    <p style="color:red; text-align:center;">
                        <?php
                        if ($error == 'contraseña_incorrecta') {
                            echo "Contraseña incorrecta. Por favor, inténtalo de nuevo.";
                        } elseif ($error == 'usuario_no_encontrado') {
                            echo "El correo electrónico no está registrado.";
                        } else {
                            echo "Ocurrió un error. Por favor, inténtalo de nuevo.";
                        }
                        ?>
                    </p>
                <?php endif; ?>

                <!-- Enlace a Registro -->
                <p class="text-center">¿No tienes cuenta? <a href="index.php?i=registro">Regístrate aquí</a></p>
            </section>
        </div>
        <div class="col"></div>
    </div>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>