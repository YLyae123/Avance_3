<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Pago</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/Layout/header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Iniciar Pago</h1>

        <div class="card mb-4">
            <div class="card-header">
                <h2>Ruta Seleccionada</h2>
            </div>
            <div class="card-body">
        <p><strong>Origen:</strong> <?php echo htmlspecialchars($ruta['ciudad_origen'] ?? 'No disponible'); ?></p>
        <p><strong>Destino:</strong> <?php echo htmlspecialchars($ruta['ciudad_destino'] ?? 'No disponible'); ?></p>
        <p><strong>Costo:</strong> $<?php echo htmlspecialchars($ruta['costo'] ?? 'No disponible'); ?> MXN</p>
        </div>
        </div>

        <form action="index.php?i=compra_exitosa" method="POST">
        <h2 class="mb-3">Detalles de Pago</h2>

     <div class="mb-3">
        <label for="nombre" class="form-label">Nombre en la Tarjeta:</label>
        <input type="text" name="nombre" id="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="numero_tarjeta" class="form-label">Número de Tarjeta:</label>
        <input type="text" name="numero_tarjeta" id="numero_tarjeta" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="fecha_expiracion" class="form-label">Fecha de Expiración:</label>
        <input type="text" name="fecha_expiracion" id="fecha_expiracion" class="form-control" placeholder="MM/AA" required>
        </div>
        <div class="mb-3">
        <label for="cvv" class="form-label">CVV:</label>
        <input type="text" name="cvv" id="cvv" class="form-control" required>
        </div>

        <input type="hidden" name="ruta_id" value="<?php echo htmlspecialchars($_SESSION['ruta_id']); ?>">

        <div class="text-center">
        <button type="submit" class="btn btn-primary">Confirmar Compra</button>
        <?$consulta = "SELECT * FROM compras (id_cliente,id_ruta,estado,fecha_compra) VALUES (:usuario_id, :ruta_id, :estado, :fecha_compra)";?>
        </div>
        </form>
    </div>

    <?php include __DIR__ . '/Layout/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>