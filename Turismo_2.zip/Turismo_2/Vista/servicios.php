<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo de Paquetes Turísticos</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>
    
    <h1>Catálogo de Paquetes Turísticos</h1>

    <section class="catalogo-paquetes">
        <div class="paquete">
            <h2>Paquete Básico</h2>
            <p>Ideal para quienes buscan una experiencia sencilla pero inolvidable.</p>
            <ul>
                <li>Traslado de ida y vuelta</li>
                <li>1 noche de alojamiento</li>
                <li>Desayuno incluido</li>
            </ul>
            <p>Precio: $100 USD</p>
        </div>

        <div class="paquete">
            <h2>Paquete Estándar</h2>
            <p>Una opción equilibrada para disfrutar de más comodidades.</p>
            <ul>
                <li>Traslado de ida y vuelta</li>
                <li>2 noches de alojamiento</li>
                <li>Desayuno y almuerzo incluidos</li>
                <li>Excursión guiada a sitios turísticos</li>
            </ul>
            <p>Precio: $200 USD</p>
        </div>

        <div class="paquete">
            <h2>Paquete Premium</h2>
            <p>La experiencia completa para los viajeros más exigentes.</p>
            <ul>
                <li>Traslado de ida y vuelta en vehículo privado</li>
                <li>3 noches de alojamiento en hotel de lujo</li>
                <li>Pensión completa (desayuno, almuerzo y cena)</li>
                <li>Excursión guiada con acceso exclusivo</li>
                <li>Servicio de spa incluido</li>
            </ul>
            <p>Precio: $400 USD</p>
        </div>
    </section>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>
