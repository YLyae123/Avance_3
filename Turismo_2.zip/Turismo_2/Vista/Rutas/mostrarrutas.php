<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Rutas de Transporte en Chiapas</title>
    <link rel="stylesheet" href="../CSS/style.css"> <!-- Ajustar la ruta de CSS -->
</head>
<body>
        <?php include __DIR__ . '/../Layout/header.php'; ?>
        <h1>Rutas de Transporte en Chiapas</h1>
    
     <div class="rutas">
        <?php
        // Incluir el modelo de rutas
        include_once ('./Modelo/rutasModel.php'); // Ajustar la ruta del modelo

        // Crear una instancia del modelo
        $rutasModel = new RutasModel();
        $rutas = $rutasModel->obtenerRutas(); // Obtener las rutas

        // Mostrar una lista de rutas disponibles
        if (!empty($rutas)): 
            echo "<h2>Ciudades Principales</h2>";
            echo "<ul>";
            foreach ($rutas as $ruta) {
                $descripcion = isset($ruta['descripcion']) ? $ruta['descripcion'] : 'No disponible';
                $tiempo_estimado = isset($ruta['tiempo_estimado']) ? $ruta['tiempo_estimado'] : 'No disponible';
                $costo = isset($ruta['costo']) ? $ruta['costo'] : 'No disponible';
            
                echo "<li><strong>{$ruta['ciudad_origen']} - {$ruta['ciudad_destino']}</strong> - $descripcion (Tiempo: $tiempo_estimado, Costo: $$costo)</li>";
            }
            echo "</ul>";
        else:
            echo "<p>No hay rutas disponibles en este momento.</p>";
        endif;
        ?>
    </div>
    
   <?php include __DIR__ . '/../Layout/footer.php'; ?>
</body>
</html>