<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinos Turísticos en Chiapas</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet"> <!-- Fuente de Google -->
</head>
<body>
    <!-- Header -->
    <?php include 'Layout/header.php'; ?>

    <!-- Hero Section -->
    <header class="hero">
        <div class="hero-content">
            <h1>Explora <span class="highlight">Chiapas</span></h1>
            <p>Descubre los destinos turísticos más impresionantes de Chiapas, llenos de cultura, naturaleza y aventura.</p>
        </div>
        <div class="hero-image">
            <img src= "Vista/IMG/mapa.jpg"  alt="Paisaje de Chiapas" />
        </div>
    </header>

    <!-- Main Content -->
    <main>
        <?php
        // Definimos los destinos turísticos
        $destinos = [
            [
                "nombre" => "Cañón del Sumidero",
                "descripcion" => "Un imponente cañón rodeado de naturaleza, donde se puede hacer un recorrido en lancha para ver la fauna y flora local.",
                "imagen" => "Vista/IMG/CSD.JPG" // Asegúrate de tener las imágenes
            ],
            [
                "nombre" => "San Cristóbal de las Casas",
                "descripcion" => "Un encantador pueblo mágico con arquitectura colonial, mercados artesanales y una vibrante cultura indígena.",
                "imagen" => "Vista/IMG/San cristobal.JPG" 
            ],
            [
                "nombre" => "Palenque",
                "descripcion" => "Un sitio arqueológico de la antigua civilización maya, rodeado de selva y lleno de historia.",
                "imagen" => "Vista/IMG/Palenque.JPG" 
            ],
            [
                "nombre" => "Lagunas de Montebello",
                "descripcion" => "Un parque nacional con lagunas de colores intensos, donde se puede disfrutar de la naturaleza y actividades al aire libre.",
                "imagen" => "Vista/IMG/Montebello.JPG" 
            ],
            [
                "nombre" => "Agua Azul",
                "descripcion" => "Hermosas cascadas de color turquesa que crean piscinas naturales perfectas para nadar y disfrutar del paisaje.",
                "imagen" => "Vista/IMG/Agua_Azul.JPG"
            ]
        ];
        ?>

        <section class="destinos">
            <h1 class="titulo-principal">Destinos Turísticos en Chiapas</h1>
            <div class="destinos-grid">
                <?php
                // Mostrar los destinos turísticos en tarjetas
                foreach ($destinos as $destino) {
                    echo "<div class='destino-card'>";
                    echo "<img src='" . $destino["imagen"] . "' alt='Imagen de " . $destino["nombre"] . "' class='destino-imagen'>";
                    echo "<h2 class='destino-nombre'>" . $destino["nombre"] . "</h2>";
                    echo "<p class='destino-descripcion'>" . $destino["descripcion"] . "</p>";
                    echo "</div>";
                }
                ?>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'Layout/footer.php'; ?>
</body>
</html>
