<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nuevo Paquete</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/../Layout/header.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Crear Nuevo Paquete</h1>

        <form action="index.php?c=procesarNuevoPaquete" method="POST">
            <div class="mb-3">
                <label for="nombre_paquete" class="form-label">Nombre del Paquete:</label>
                <input type="text" name="nombre_paquete" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="descripcion" class="form-label">Descripción:</label>
                <textarea name="descripcion" class="form-control" rows="4" required></textarea>
            </div>

            <div class="mb-3">
                <label for="costo" class="form-label">Costo:</label>
                <input type="number" name="costo" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="cupo_maximo" class="form-label">Cupo Máximo:</label>
                <input type="number" name="cupo_maximo" class="form-control" required>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success">Crear Paquete</button>
                <a href="index.php?c=mostrarCatalogo" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>

    <?php include __DIR__ . '/../Layout/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>