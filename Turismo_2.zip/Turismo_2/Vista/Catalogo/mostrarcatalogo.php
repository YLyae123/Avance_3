<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo de Paquetes Turísticos</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include __DIR__ . '/../Layout/header.php'; ?>

    <h1>Catálogo de Paquetes Turísticos</h1>

    <!-- Botón para crear un nuevo paquete, solo visible para administradores -->
    <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] == 1): ?>
        <a href="index.php?c=mostrarFormularioNuevoPaquete" class="btn btn-primary">Crear Nuevo Paquete</a>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger">
            <?php
                if ($_GET['error'] == 'paquete_no_encontrado') {
                    echo "El paquete solicitado no fue encontrado.";
                } elseif ($_GET['error'] == 'id_invalido') {
                    echo "ID inválido.";
                } elseif ($_GET['error'] == 'solicitud_no_valida') {
                    echo "La solicitud no es válida.";
                }
            ?>
        </div>
    <?php endif; ?>

    <section class="catalogo-paquetes">
        <?php if (!empty($paquetes)): ?>
            <?php foreach ($paquetes as $paquete): ?>
                <div class="paquete">
                    <h2><?php echo htmlspecialchars($paquete['nombre_paquete']); ?></h2>
                    <p><?php echo htmlspecialchars($paquete['descripcion']); ?></p>
                    <ul>
                        <li>Costo: $<?php echo htmlspecialchars($paquete['costo']); ?> MX</li>
                        <li>Cupo máximo: <?php echo htmlspecialchars($paquete['cupo_maximo']); ?> personas</li>
                    </ul>
                    <div class="acciones">
                        <!-- Botones para administradores -->
                        <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] == 1): ?>
                            <a href="index.php?c=editarPaquete&id=<?php echo $paquete['id_paquete']; ?>" class="btn btn-warning">Modificar</a>
                            <a href="index.php?c=eliminarPaquete&id=<?php echo $paquete['id_paquete']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este paquete?');">Eliminar</a>
                        <?php endif; ?>

                        <!-- Botón para clientes -->
                        <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] == 2): ?>
                            <a href="index.php?c=reserva&id=<?php echo $paquete['id_paquete']; ?>" class="btn btn-success">Reservar</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No hay paquetes disponibles en este momento.</p>
        <?php endif; ?>
    </section>

    <?php include __DIR__ . '/../Layout/footer.php'; ?>
</body>
</html>