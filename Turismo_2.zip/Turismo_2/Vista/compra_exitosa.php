<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Compra Exitosa</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <div class="container mt-5">
        <h2>¡Compra Exitosa!</h2>
        <p>Gracias por tu compra. Tu reserva ha sido procesada con éxito.</p>
        <a href="index.php?i=verMisCompras" class="btn btn-primary">Ver Mis Compras</a>
        <?$consulta = "INSERT INTO compras (id_cliente,id_ruta,estado,fecha_compra) VALUES (:usuario_id, :ruta_id, :estado, :fecha_compra)";?>
    </div>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>