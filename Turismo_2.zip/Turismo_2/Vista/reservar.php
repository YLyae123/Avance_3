<?php
// Controlador de reservas

require_once('./Controlador/ReservaController.php');
$reservaController = new ReservaController();
$reservaController->mostrarFormularioReserva();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservar Paquete</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <h1>Reservar Paquete</h1>

    <?php
    // Incluir el modelo de rutas
    include_once('./Modelo/rutasModel.php'); 
    $rutasModel = new RutasModel();
    $rutas = $rutasModel->obtenerRutas(); // Obtener las rutas desde la base de datos

    if (empty($rutas)) {
        echo "<p>No hay rutas disponibles en este momento.</p>";
    } else {
    ?>
    <form action="index.php?i=procesarReserva" method="POST">
    <div class="rutas">
        <h2>Selecciona una Ruta</h2>
        <select name="ruta_id" required>
            <option value="">Selecciona una ruta</option>
            <?php foreach ($rutas as $ruta): ?>
                <option value="<?php echo htmlspecialchars($ruta['id']); ?>">
                    <?php echo htmlspecialchars($ruta['ciudad_origen'] . ' - ' . $ruta['ciudad_destino']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="text-center mb-4">
        <button type="submit" class="btn btn-success">Iniciar Pago</button>
    </div>
</form>
    <?php } ?>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>