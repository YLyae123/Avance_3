<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Iniciar la sesión solo si no hay una activa
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turismo Aventura Chiapas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="favicon-32x32.png" type="image/png">
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <div class="d-flex align-items-center">
            <?php if (isset($_SESSION['nombre_usuario'])): ?>
                <span class="text-white me-3" style="margin-left: 0;">Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre_usuario']); ?></span>
                
            <?php endif; ?>
            <a class="navbar-brand d-flex align-items-center" href="index.php"> 
                <img src="Vista/IMG/logo.png" alt="Logo" style="width: 40px; height: auto; margin-right: 10px;">
                Turismo Aventura Chiapas
            </a>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php?action=inicio">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?i=destinos">Destinos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?r=mostrarrutas">Rutas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?c=mostrarcatalogo">Catálogo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?i=contacto">Contacto</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?i=info">Información de Chiapas</a>
                </li>
                <?php if (isset($_SESSION['nombre_usuario']) && isset($_SESSION['rol']) && $_SESSION['rol'] == 2): // Solo clientes ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?i=verMisCompras">Compras</a>
                    </li>
                <?php endif; ?>
                <?php if (isset($_SESSION['nombre_usuario']) && isset($_SESSION['rol']) && $_SESSION['rol'] == 1): // Solo administradores ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?c=comprasAdmin">Compras Administrador</a>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto">
                <?php if (!isset($_SESSION['nombre_usuario'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?i=login">Iniciar sesión</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a href="logout.php" class="btn btn-outline-light btn-sm" style="padding: 5px 3px;">Cerrar sesión</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
</header>
</body>
</html>