<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Rutas de Transporte en Chiapas</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>
    <h1>Rutas de Transporte en Chiapas</h1>
    
    <div class="rutas">
        <?php
        // Incluir las rutas
        include 'rutas.php';

        // Mostrar una lista de rutas disponibles
        echo "<h2>Ciudades Principales</h2>";
        echo "<ul>";
        foreach ($rutas as $ciudad => $destinos) {
            echo "<li><strong>$ciudad</strong>";
            echo "<ul>";
            foreach ($destinos as $destino => $descripcion) {
                echo "<li>$destino - $descripcion</li>";
            }
            echo "</ul></li>";
        }
        echo "</ul>";
        ?>
    </div>
    
    <?php include 'Layout/footer.php'; ?>
</body>
</html>
