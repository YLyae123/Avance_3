<?php
require('../../Controlador/fpdf186/fpdf.php'); // Asegúrate de que la ruta sea correcta

// Crear una instancia de FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Agregar el logotipo
$logoPath = '../../Vista/IMG/logo.png'; // Ajusta la ruta a tu logotipo
$pdf->Image($logoPath, 10, 8, 33); // (ruta, x, y, ancho)

// Título
$pdf->Cell(0, 10, 'Turismo Aventura Chiapas', 0, 1, 'C');
$pdf->Ln(10); // Espacio entre el título y el contenido

// Detalles de la compra
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'ID Compra: 1', 0, 1);
$pdf->Cell(0, 10, 'ID Paquete: 10002', 0, 1);
$pdf->Cell(0, 10, 'Fecha de Reserva: 21 de noviembre de 2024', 0, 1);
$pdf->Cell(0, 10, 'Estado: Confirmada', 0, 1);
$pdf->Cell(0, 10, 'Monto: $6000.00', 0, 1); // Reemplaza XXX.XX con el monto real

// Salida del PDF
$pdf->Output();
?> 