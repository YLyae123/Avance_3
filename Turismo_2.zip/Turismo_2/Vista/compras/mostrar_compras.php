<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Compras</title>
    <link rel="stylesheet" href="../CSS/style.css"> <!-- Ajusta la ruta si es necesario -->
</head>
<body>
<?php include __DIR__ . '/../Layout/header.php'; ?> <!-- Asegúrate de que la ruta sea correcta -->

<div class="container mt-5">
    <h2>Mis Compras</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID Compra</th>
                <th>ID Paquete</th>
                <th>Fecha de Reserva</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo htmlspecialchars(1); ?></td>
                <td><?php echo htmlspecialchars(10002); ?></td>
                <td><?php echo htmlspecialchars('21 de noviembre de 2024'); ?></td>
                <td><?php echo htmlspecialchars('confirmada'); ?></td>
            </tr>
        </tbody>
    </table>
    <div class="text-end mt-3"> <!-- Alineación a la derecha -->
        <a href="Vista/compras/generar_recibo.php" class="btn btn-primary">Imprimir Recibo</a>
    </div>
</div>

<?php include __DIR__ . '/../Layout/footer.php'; ?><!-- Asegúrate de que la ruta sea correcta -->
</body>
</html>