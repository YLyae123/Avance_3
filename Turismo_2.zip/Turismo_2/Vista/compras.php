<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Compras</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>

    <div class="container mt-5">
        <h2>Mis Compras</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID Compra</th>
                    <th>ID Paquete</th>
                    <th>Fecha de Reserva</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
<?php if (!empty($compras)): ?>
    <?php foreach ($compras as $compra): ?>
        <tr>
            <td><?php echo htmlspecialchars($compra['id_compra']); ?></td>
            <td><?php echo htmlspecialchars($compra['id_ruta']); ?></td>
            <td><?php echo htmlspecialchars($compra['fecha_compra']); ?></td>
            <td><?php echo htmlspecialchars($compra['estado']); ?></td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="4" class="text-center">No tienes compras registradas.</td>
    </tr>
<?php endif; ?>
</tbody>
        </table>
    </div>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>