<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" href="Vista/CSS/style.css">
</head>
<body>
    <?php include 'Layout/header.php'; ?>
    
    <h2 class="text-center">Registro de Usuario</h2>
    
    <div class="container">
    <form action="index.php?i=registro" method="POST">
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="formnombre" id="floatingNombre" required>
            <label for="floatingNombre">Nombre</label>
        </div>
        
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="formpaterno" id="floatingPaterno" required>
            <label for="floatingPaterno">Apellido Paterno</label>
        </div>
        
        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="formmaterno" id="floatingMaterno" required>
            <label for="floatingMaterno">Apellido Materno</label>
        </div>
        
        <div class="form-floating mb-3">
            <input type="email" class="form-control" name="formemail" id="floatingEmail" required>
            <label for="floatingEmail">Email</label>
        </div>
        
        <div class="form-floating mb-3">
            <input type="password" class="form-control" name="formpass" id="floatingPassword" required>
            <label for="floatingPassword">Contraseña</label>
        </div>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" name="formtelefono" id="floatingTelefono">
            <label for="floatingTelefono">Teléfono</label>
        </div>

        <div class="form-floating mb-3">
            <select class="form-control" name="formid_puesto" id="floatingIdPuesto" required>
                <option value="">Selecciona un puesto</option>
                <option value="1">Administrador</option>
                <option value="2">Cliente</option>
            </select>
            <label for="floatingIdPuesto">Puesto</label>
        </div>

        <div class="text-center mb-4">
            <button type="submit" class="btn btn-success">Registrar</button>
        </div>

        <!-- Mensajes de Error -->
        <?php if (isset($error)): ?>
            <p style="color:red; text-align:center;">
                <?php echo htmlspecialchars($error); ?>
            </p>
        <?php endif; ?>
    </form>
        
        <center>
            <p>¿Ya tienes cuenta? <a href="index.php?i=login">Inicia sesión aquí</a></p>
        </center>
    </div>

    <?php include 'Layout/footer.php'; ?>
</body>
</html>