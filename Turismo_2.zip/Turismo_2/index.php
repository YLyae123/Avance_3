<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// index.php
require("Controlador/IndexController.php");
require("Controlador/catalogoController.php");
require("Controlador/rutasController.php");
require("Controlador/usuarioController.php"); 
require("Controlador/ReservaController.php");
require("Controlador/ComprasController.php"); // Incluir el controlador de compras
require("Controlador/ComprasAdminController.php"); // Incluir el controlador de compras para administradores

// Manejo de acciones a través de parámetros GET
if (isset($_GET['i'])) {
    $metodo = $_GET['i'];
    switch ($metodo) {
        case 'registro':
            $usuarioController = new UsuarioController();
            $usuarioController->registrar(); 
            break;
        case 'inicio':
            $usuarioController = new UsuarioController();
            $usuarioController->ingresar();
            break;
        case 'procesarReserva':
            $reservaController = new ReservaController();
            $reservaController->procesarReserva(); 
            break;
        case 'procesarPago': // Manejo del procesamiento de pago
            $reservaController = new ReservaController();
            $reservaController->procesarPago(); 
            break;
        case 'compras': // Mostrar compras de clientes
            $comprasController = new ComprasController();
            $comprasController->mostrarCompras();
            break;
        case 'compra_exitosa': // Redirigir a la página de compra exitosa
            require_once("Vista/compra_exitosa.php");
            exit;
            case 'verMisCompras': // Redirigir a la página de compras del usuario
                $comprasController = new ComprasController();
                $comprasController->mostrarCompras();
                break;
        default:
            if (method_exists('IndexController', $metodo)) {
                IndexController::{$metodo}();
            } else {
                IndexController::index(); // Redirigir a la página de inicio si el método no existe
            }
            break;
    }
} elseif (isset($_GET['c'])) {
    $metodo = $_GET['c'];
    if ($metodo === 'comprasAdmin') { // Manejo de las acciones de compras para administradores
        $comprasAdminController = new ComprasAdminController();
        $comprasAdminController->listar(); // Método para listar las compras
    } elseif (method_exists('CatalogoController', $metodo)) {
        $catalogoController = new CatalogoController();
        $catalogoController->{$metodo}();
    }
} elseif (isset($_GET['r'])) {
    $metodo = $_GET['r'];
    if (method_exists('RutasController', $metodo)) {
        $rutasController = new RutasController();
        $rutasController->{$metodo}();
    }
} else {
    IndexController::index(); // Cargar la página de inicio si no hay parámetros
}
?>