<?php
include_once("Modelo/usuarioModel.php");

class UsuarioAdminController {
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new UsuarioModel();
    }

    // Método para listar todos los usuarios
    public function listarUsuarios() {
        $usuarios = $this->usuarioModel->obtenerTodosLosUsuarios();
        require_once("Vista/admin/gestionar_usuarios.php");
    }

    // Método para mostrar el formulario de creación de usuario
    public function mostrarFormularioCrear() {
        require_once("Vista/admin/crear_usuario.php");
    }

    // Método para procesar la creación de un nuevo usuario
    public function crearUsuario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'];
            $apaterno = $_POST['apaterno'];
            $amaterno = $_POST['amaterno'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $telefono = $_POST['telefono'];
            $id_puesto = $_POST['id_puesto'];

            // Llamar al modelo para registrar el nuevo usuario
            $resultado = $this->usuarioModel->registrarUsuario($nombre, $apaterno, $amaterno, $email, $password, $telefono, $id_puesto);

            if ($resultado === true) {
                header("Location: index.php?c=usuarioAdmin&accion=listar"); // Redirigir a la lista de usuarios
                exit;
            } else {
                // Manejo de error al crear usuario
                header("Location: index.php?c=usuarioAdmin&accion=mostrarFormularioCrear&error=" . urlencode($resultado));
                exit;
            }
        }
    }

    // Método para mostrar el formulario de edición de usuario
    public function mostrarFormularioEditar($id) {
        $usuario = $this->usuarioModel->obtenerUsuarioPorId($id);
        require_once("Vista/admin/editar_usuario.php");
    }

    // Método para procesar la edición de un usuario
    public function editarUsuario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            $nombre = $_POST['nombre'];
            $apaterno = $_POST['apaterno'];
            $amaterno = $_POST['amaterno'];
            $email = $_POST['email'];

            // Llamar al modelo para modificar el usuario
            $resultado = $this->usuarioModel->modificarUsuario($id, $nombre, $apaterno, $amaterno, $email);

            if ($resultado) {
                header("Location: index.php?c=usuarioAdmin&accion=listar"); // Redirigir a la lista de usuarios
                exit;
            } else {
                // Manejo de error al editar usuario
                header("Location: index.php?c=usuarioAdmin&accion=mostrarFormularioEditar&id=" . $id . "&error=error_modificar");
                exit;
            }
        }
    }

    // Método para eliminar un usuario
    public function eliminarUsuario($id) {
        $resultado = $this->usuarioModel->eliminarUsuario($id);
        header("Location: index.php?c=usuarioAdmin&accion=listar"); // Redirigir a la lista de usuarios
        exit;
    }
}
?>