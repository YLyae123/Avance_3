<?php
include_once("Modelo/reservaModel.php");

class ComprasAdminController {
    private $reservaModel;

    public function __construct() {
        $this->reservaModel = new ReservaModel(); // Inicializar el modelo de reservas
    }

    public function listar() {
        // Obtener todas las compras o reservas de la base de datos
        $compras = $this->reservaModel->obtenerReservas(); // Método que devuelve todas las reservas
        require 'Vista/comprasAdmin.php'; // Cargar la vista para mostrar las compras
    }
}