<?php
include_once("Modelo/ReservaModel.php");
include_once("Modelo/ComprasModel.php"); // Incluir el modelo de compras

class ComprasController {
    private $reservaModel;
    private $comprasModel;

    public function __construct() {
        $this->reservaModel = new ReservaModel();
        $this->comprasModel = new ComprasModel(); // Inicializar el modelo de compras
    }

    public function mostrarCompras() {
        session_start();
        
        if (!isset($_SESSION['usuario_id'])) {
            include("Vista/compras/mostrar_compras.php");
            exit;
        }
        
        
        require_once("../Vista/compras/mostrar_compras.php"); // Cargar la vista de compras
    }

    public function confirmarPago($usuario_id, $ruta_id) {
    // Validar que el usuario y la ruta sean válidos
    if (empty($usuario_id) || empty($ruta_id)) {
        echo "Datos de usuario o ruta no válidos.";
        return;
    }

    // Lógica para procesar el pago
    $pagoExitoso = $this->procesarPago($usuario_id, $ruta_id); // Implementa esta función según tu lógica de pago

    if ($pagoExitoso) {
        // Si el pago es exitoso, guarda la compra
        $estado = 'confirmada'; // O el estado que desees
        $resultado = $this->comprasModel->agregarCompra($usuario_id, $ruta_id, $estado);

        if ($resultado) {
            // Redirigir a la página de compras después de guardar
            header("Location: index.php?i=verMisCompras"); // Asegúrate de que esta ruta sea correcta
            exit;
        } else {
            // Manejar el error de inserción
            error_log("Error al guardar la compra para el usuario ID: $usuario_id y ruta ID: $ruta_id");
            echo "Ocurrió un error al procesar su compra. Por favor, inténtelo de nuevo más tarde.";
        }
    } else {
        echo "El pago no fue exitoso. Por favor, verifique sus datos de pago.";
    }
}

    // Método simulado para procesar el pago
    public function procesarPago() {
        session_start(); // Iniciar la sesión
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ruta_id = $_POST['ruta_id']; // Obtener el ID de la ruta del formulario
            $usuario_id = $_SESSION['usuario_id']; // Asegúrate de que el ID del usuario esté en la sesión
    
            // Lógica para procesar el pago
            $pagoExitoso = $this->procesarPagoConDatos($usuario_id, $ruta_id, $_POST); // Implementa esta función según tu lógica de pago
    
            if ($pagoExitoso) {
                // Guardar la reserva
                if ($this->reservaModel->guardarReserva($ruta_id, $usuario_id)) {
                    $_SESSION['success'] = "Reserva realizada con éxito."; // Mensaje de éxito
                    header("Location: index.php?i=compra_exitosa"); // Redirigir a la página de compra exitosa
                    exit();
                } else {
                    $_SESSION['error'] = "Error al realizar la reserva. Por favor, intenta nuevamente."; // Mensaje de error
                    header("Location: Vista/iniciar_pago.php"); // Redirigir a la página de inicio de pago
                    exit();
                }
            } else {
                $_SESSION['error'] = "El pago no fue exitoso. Por favor, verifique sus datos de pago."; // Mensaje de error
                header("Location: Vista/iniciar_pago.php"); // Redirigir a la página de inicio de pago
                exit();
            }
        } else {
            $_SESSION['error'] = "Método de solicitud no válido."; // Mensaje de error
            header("Location: Vista/iniciar_pago.php"); // Redirigir a la página de inicio de pago
            exit();
        }
    }
    
    // Método simulado para procesar el pago
    private function procesarPagoConDatos($usuario_id, $ruta_id, $datosPago) {
        // Aquí debes implementar la lógica para procesar el pago
        // Por ejemplo, llamar a una API de pago o realizar una verificación de pago
    
        // Simulación de un pago exitoso
        // En un caso real, aquí deberías manejar la lógica de pago y devolver true o false
        return true; // Cambia esto según la lógica real de tu procesamiento de pagos
    }
}
?>