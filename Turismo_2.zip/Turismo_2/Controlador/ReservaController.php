<?php
include_once("Modelo/rutasModel.php");
include_once("Modelo/reservaModel.php"); // Incluir el modelo de reservas

class ReservaController {
    private $rutasModel;
    private $reservaModel;

    // Constructor para inicializar los modelos
    public function __construct() {
        $this->rutasModel = new RutasModel(); // Inicializar el modelo de rutas
        $this->reservaModel = new ReservaModel(); // Inicializar el modelo de reservas
    }

    // Método para mostrar el formulario de reserva
    public function mostrarFormularioReserva() {
        $rutas = $this->rutasModel->obtenerRutas(); // Obtener todas las rutas
        require_once("Vista/reservar.php"); // Cargar la vista del formulario de reserva
    }

    // Método para procesar la reserva
    public function procesarReserva() { 
        session_start(); // Iniciar la sesión
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ruta_id'])) {
            $ruta_id = filter_input(INPUT_POST, 'ruta_id', FILTER_SANITIZE_NUMBER_INT);
            
            if ($ruta_id) {
                $_SESSION['ruta_id'] = $ruta_id; // Almacenar el ID de la ruta en la sesión
                
                // Obtener información de la ruta seleccionada
                $ruta = $this->rutasModel->obtenerRutaPorId($ruta_id); // Obtener información de la ruta
                
                if ($ruta) {
                    // Redirigir a la página de inicio de pago con la información de la ruta
                    require("Vista/iniciar_pago.php"); // Mostrar la vista de iniciar pago
                    exit();
                } else {
                    $_SESSION['error'] = "Ruta no encontrada. Por favor, vuelve a intentarlo.";
                    header("Location: Vista/reservar.php"); // Redirección en caso de error
                    exit();
                }
            } else {
                $_SESSION['error'] = "ID de ruta no válido. Por favor, vuelve a intentarlo.";
                header("Location: Vista/reservar.php"); // Redirección en caso de error
                exit();
            }
        } else {
            $_SESSION['error'] = "No se ha seleccionado ninguna ruta. Por favor, vuelve a intentarlo.";
            header("Location: Vista/reservar.php"); // Redirigir al formulario de reserva
            exit();
        }
    }
    
    // Método para procesar el pago
    public function procesarPago() {
        session_start(); // Iniciar la sesión
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ruta_id = $_POST['ruta_id']; // Obtener el ID de la ruta del formulario
            $usuario_id = $_SESSION['usuario_id']; // Asegúrate de que el ID del usuario esté en la sesión
    
            // Guardar la reserva
            if ($this->reservaModel->guardarReserva($ruta_id, $usuario_id)) {
                $_SESSION['success'] = "Reserva realizada con éxito."; // Mensaje de éxito
                header("Location: index.php?i=compra_exitosa"); // Redirigir a la página de compra exitosa
                exit();
            } else {
                $_SESSION['error'] = "Error al realizar la reserva. Por favor, intenta nuevamente."; // Mensaje de error
                header("Location: Vista/iniciar_pago.php"); // Redirigir a la página de inicio de pago
                exit();
            }
        } else {
            $_SESSION['error'] = "Método de solicitud no válido."; // Mensaje de error
            header("Location: Vista/iniciar_pago.php"); // Redirigir a la página de inicio de pago
            exit();
        }
    }

    // Método para iniciar el proceso de pago
    public function iniciarPago() {
        session_start(); // Iniciar la sesión para acceder a las variables de sesión
    
        // Verificar si se ha seleccionado una ruta
        if (!isset($_SESSION['ruta_id'])) {
            // Si no hay ruta seleccionada, redirigir al formulario de reserva
            header("Location: Vista/reservar.php");
            exit();
        }
    
        // Obtener información de la ruta seleccionada
        $ruta = $this->rutasModel->obtenerRutaPorId($_SESSION['ruta_id']); // Obtener información de la ruta
    
        // Verificar si la ruta existe
        if (!$ruta) {
            // Si no se encuentra la ruta, redirigir al formulario de reserva
            header("Location: Vista/reservar.php");
            exit();
        }
    
        // Si todo está bien, mostrar la vista de iniciar pago
        require_once("Vista/iniciar_pago.php"); // Mostrar la vista de iniciar pago
    }

}
?>