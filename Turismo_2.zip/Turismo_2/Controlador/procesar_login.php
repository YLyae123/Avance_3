<?php
session_start(); // Iniciar la sesión

// Conectar a la base de datos
include_once('./Modelo/conexion.php');
$conexion = new Conexion();

// Verificar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    echo $usuario;
    // Consulta para verificar el usuario y la contraseña
    $consulta = "SELECT nombre, apaterno, amaterno, contraseña, id_usuario FROM clientes WHERE email = :usuario"; 
    $stmt = $conexion->prepare($consulta);
    $stmt->execute([':usuario' => $usuario]);

    // Verificar si se encontró el usuario
    if ($stmt->rowCount() > 0) {
        $usuarioData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Concatenar nombre y apellidos
        $nombreCompleto = $usuarioData['nombre'] . ' ' . $usuarioData['apaterno'] . ' ' . $usuarioData['amaterno'];
        echo $nombreCompleto;
        // Verificar la contraseña
        if (password_verify($password, $usuarioData['contraseña'])) {
            // Almacenar el nombre completo en la sesión
            
            $_SESSION['nombre_usuario'] = $nombreCompleto;
            header("Location: index.php"); // Redirigir a la página principal
            exit;
        } else {
            // Contraseña incorrecta
            header("Location: login.php?error=1");
            exit;
        }
    } else {
        // Usuario no encontrado
        header("Location: login.php?error=usuario_no_encontrado");
        exit;
    }
} else {
    // Si no se envió el formulario, redirigir a la página de inicio de sesión
    header("Location: login.php");
    exit;
}
?>