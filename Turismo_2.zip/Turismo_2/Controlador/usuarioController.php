<?php
// Controlador/usuarioController.php
include_once('./Modelo/usuarioModel.php');

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        session_start(); // Asegúrate de que la sesión esté activa
        $this->usuarioModel = new UsuarioModel();
    }

   // Controlador/usuarioController.php
   // Controlador/usuarioController.php
public function registrar() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obtener y validar los datos del formulario
        $nombre = $_POST['formnombre'];
        $apaterno = $_POST['formpaterno'];
        $amaterno = $_POST['formmaterno'];
        $email = $_POST['formemail'];
        $password = $_POST['formpass'];
        $telefono = $_POST['formtelefono'];
        $id_puesto = $_POST['formid_puesto'];

        // Llamar al modelo para registrar el usuario
        $resultado = $this->usuarioModel->registrarUsuario($nombre, $apaterno, $amaterno, $email, $password, $telefono, $id_puesto);

        if ($resultado === true) {
            // Registro exitoso, redirigir a la página de inicio de sesión
            header("Location: index.php?i=login&mensaje=Registro exitoso. Por favor inicia sesión.");
            exit;
        } else {
            // En lugar de redirigir, incluimos el error en la vista
            $error = $resultado; // Guardar el mensaje de error
            require_once("Vista/registro.php"); // Mostrar la vista de registro con el error
            exit;
        }
    } else {
        // Si no se envió el formulario, mostrar la vista de registro
        require_once("Vista/registro.php");
    }
}

public function ingresar() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['usuario'];
        $password = $_POST['password'];

        // Llamar al modelo para manejar el inicio de sesión del usuario
        $resultado = $this->usuarioModel->ingresarUsuario($email, $password);

        if ($resultado === true) {
            // Obtener datos del usuario para almacenar en la sesión
            $usuarioData = $this->usuarioModel->getUserDataByEmail($email);
            $_SESSION["nombre_usuario"] = $usuarioData['nombre'] . ' ' . $usuarioData['apaterno'];
            $_SESSION["rol"] = $usuarioData['id_puestos'];
            header("Location: index.php");
            exit;
        } else {
            // En lugar de redirigir, incluimos el error en la vista
            $error = $resultado; // Guardar el mensaje de error
            require_once("Vista/login.php"); // Mostrar la vista de login con el error
            exit;
        }
    } else {
        // Si el formulario no fue enviado, mostrar el formulario de inicio de sesión
        require_once("Vista/login.php");
    } 
}

    public function modificarUsuario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Obtener datos del formulario
            $id = $_POST['id'];
            $nombre = $_POST['formnombre'];
            $apaterno = $_POST['formpaterno'];
            $amaterno = $_POST['formmaterno'];
            $email = $_POST['formemail'];
    
            // Llamar al modelo para modificar el usuario
            $resultado = $this->usuarioModel->modificarUsuario($id, $nombre, $apaterno, $amaterno, $email);
            
            if ($resultado) {
                header("Location: index.php?c=mostrarUsuarios&mensaje=Usuario modificado con éxito");
                exit;
            } else {
                // Manejo de error
                header("Location: index.php?c=modificarUsuario&id=$id&error=modificacion_fallida");
                exit;
            }
        } else {
            // Mostrar formulario de edición
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $usuario = $this->usuarioModel->obtenerUsuarioPorId($id);
                if ($usuario) {
                    require_once("Vista/Catalogo/editar.php");
                } else {
                    header("Location: index.php?c=mostrarUsuarios&error=usuario_no_encontrado");
                    exit;
                }
            } else {
                header("Location: index.php?c=mostrarUsuarios");
                exit;
            }
        }
    }

    public function eliminarUsuario() {
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            
            // Llamar al modelo para eliminar el usuario
            $resultado = $this->usuarioModel->eliminarUsuario($id);
            
            if ($resultado) {
                header("Location: index.php?c=mostrarUsuarios&mensaje=Usuario eliminado con éxito");
                exit;
            } else {
                // Manejo de error
                header("Location: index.php?error=eliminacion_fallida");
                exit;
            }
        }
    }
}
?>