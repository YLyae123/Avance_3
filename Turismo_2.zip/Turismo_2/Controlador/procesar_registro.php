<?php
session_start(); // Iniciar la sesión

// Conectar a la base de datos
include_once('Modelo/conexion.php');
$conexion = new Conexion();

// Verificar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Consulta para verificar el usuario y la contraseña
    $consulta = "SELECT * FROM cleintes WHERE email = :usuario"; // Cambia 'email' por el campo que uses para el usuario
    $stmt = $conexion->prepare($consulta);
    $stmt->execute([':usuario' => $usuario]);

    // Verificar si se encontró el usuario
    if ($stmt->rowCount() > 0) {
        $usuarioData = $stmt->fetch(PDO::FETCH_ASSOC);
        $nombre = $usuarioData['nombre'];

        // Verificar la contraseña (asumiendo que la contraseña está hasheada)
        if (password_verify($password, $usuarioData['contraseña'])) { // Asegúrate de que 'contraseña' esté en la consulta
            // Almacenar el nombre del usuario en la sesión
            $_SESSION['nombre_usuario'] = $nombre;

            // Redirigir a la página principal
            header("Location: index.php");
            exit;
        } else {
            // Contraseña incorrecta
            header("Location: login.php?error=1");
            exit;
        }
    } else {
        // Usuario no encontrado
        header("Location: login.php?error=1");
        exit;
    }
}
?>