<?php
include_once("Modelo/rutasModel.php");

class RutasController {
    private $rutasModel;

    public function __construct() {
        $this->rutasModel = new RutasModel();
    }

    public function mostrarRutas() {
        $rutas = $this->rutasModel->obtenerRutas();
        require_once("Vista/Rutas/mostrarrutas.php");
    }
}
?>