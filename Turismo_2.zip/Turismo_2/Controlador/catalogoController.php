<?php
include_once("Modelo/catalogoModel.php");

class CatalogoController {
    private $catalogoModel;

    public function __construct() {
        $this->catalogoModel = new CatalogoModel();
    }

    // Método para mostrar el catálogo de paquetes
    public function mostrarCatalogo() {
        $paquetes = $this->catalogoModel->obtenerPaquetes();
        require_once("Vista/Catalogo/mostrarcatalogo.php");
    }

    // Método para mostrar el formulario de creación de un nuevo paquete
    public function mostrarFormularioNuevoPaquete() {
        require_once __DIR__ . '/../Vista/Catalogo/nuevo.php'; // Cargar la vista del formulario
    }

    // Método para procesar la creación de un nuevo paquete
    public function procesarNuevoPaquete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Obtener los datos del formulario
            $nombre_paquete = $_POST['nombre_paquete'];
            $descripcion = $_POST['descripcion'];
            $costo = $_POST['costo'];
            $cupo_maximo = $_POST['cupo_maximo'];
    
            // Validar los datos
            if (!empty($nombre_paquete) && !empty($descripcion) && is_numeric($costo) && is_numeric($cupo_maximo)) {
                try {
                    // Llamar al modelo para crear un nuevo paquete
                    $this->catalogoModel->crearPaquete($nombre_paquete, $descripcion, $costo, $cupo_maximo);
                    // Redirigir a la página del catálogo después de la creación
                    header("Location: index.php?c=mostrarCatalogo");
                    exit;
                } catch (Exception $e) {
                    // Manejo de error: mostrar el mensaje de error
                    header("Location: Vista/Catalogo/nuevo.php?error=" . urlencode($e->getMessage()));
                    exit;
                }
            } else {
                // Manejo de error: datos inválidos
                header("Location: Vista/Catalogo/nuevo.php?error=datos_invalidos");
                exit;
            }
        } else {
            // Manejo de error: solicitud no válida
            header("Location: Vista/Catalogo/nuevo.php?error=solicitud_no_valida");
            exit;
        }
    }

    // Método para modificar un paquete existente
    public function editarPaquete() {
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $id_paquete = $_GET['id']; // Obtener el ID del paquete desde la URL
            $paquete = $this->catalogoModel->obtenerPaquetePorId($id_paquete); // Obtener los datos del paquete
            
            // Verifica si el paquete fue encontrado
            if ($paquete) {
                require_once("Vista/Catalogo/editar.php"); // Cargar la vista de edición
            } else {
                // Manejo de error: paquete no encontrado
                header("Location: index.php?c=mostrarCatalogo&error=paquete_no_encontrado");
                exit;
            }
        } else {
            // Manejo de error: ID inválido
            header("Location: index.php?c=mostrarCatalogo&error=id_invalido");
            exit;
        }
    }

    // Método para actualizar un paquete existente
    public function actualizarPaquete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Obtener los datos del formulario
            $id_paquete = $_POST['id'];
            $nombre_paquete = $_POST['nombre_paquete'];
            $descripcion = $_POST['descripcion'];
            $costo = $_POST['costo'];
            $cupo_maximo = $_POST['cupo_maximo'];
    
            // Llamar al modelo para modificar el paquete
            $this->catalogoModel->modificarPaquete($id_paquete, $nombre_paquete, $descripcion, $costo, $cupo_maximo);
            
            // Redirigir después de la actualización
            header("Location: index.php?c=mostrarCatalogo");
            exit;
        } else {
            // Manejo de error: solicitud no válida
            header("Location: index.php?c=mostrarCatalogo&error=solicitud_no_valida");
            exit;
        }
    }

    // Método para eliminar un paquete
    public function eliminarPaquete() {
        if (isset($_GET['id']) && is_numeric($_GET['id'])) {
            $id_paquete = $_GET['id']; // Obtener el ID del paquete desde la URL
            $this->catalogoModel->eliminarPaquete($id_paquete); // Eliminar el paquete
            header("Location: index.php?c=mostrarCatalogo"); // Redirigir después de la eliminación
            exit;
        } else {
            // Manejo de error: ID inválido
            header("Location: index.php?c=mostrarCatalogo&error=id_invalido");
            exit;
        }
    }
    public function reserva() {
        if (isset($_GET['id'])) {
            $id_paquete = $_GET['id'];
            // Aquí deberías obtener los detalles del paquete usando el ID
            $paquete = $this->catalogoModel->obtenerPaquetePorId($id_paquete);

            if ($paquete) {
                require_once("./Vista/reservar.php"); // Asegúrate de que la vista exista
            } else {
                // Manejo de error: paquete no encontrado
                header("Location: index.php?c=mostrarCatalogo&error=paquete_no_encontrado");
                exit;
            }
        } else {
            // Manejo de error: ID no válido
            header("Location: index.php?c=mostrarCatalogo&error=id_invalido");
            exit;
        }
    }
}
?>