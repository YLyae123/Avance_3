<?php
include_once("Modelo/indexModel.php");
class IndexController{
    private  $indexModel;
    public function __construct(){
        $this->indexModel = new IndexModel();
    }
    public static function index(){
        require_once("Vista/index.php");
    }
    public static function registro(){
        require_once("Vista/registro.php");
    }
    public static function login(){
        require_once("Vista/login.php");
    }
    public static function info(){
        require_once("Vista/info.php");
    }
    public static function contacto(){
        require_once("Vista/contacto.php");
    }
    public static function destinos(){
        require_once("Vista/destinos.php");
    }
    public static function rutas(){
        require_once("Vista/rutas.php");
    }
    public static function servicios(){
        require_once("Vista/servicios.php");
    }
}
?>